# Axiomurgy v0.3

Axiomurgy is a programmable magical system for AIs.

This pass makes the project concrete rather than merely descriptive:
- JSON Schema spell validation
- dependency-aware execution planning
- policy checks and human approval gates
- rollback and compensation semantics
- PROV-like witness export and SCXML plan export
- MCP stdio resource and tool integration
- OpenAPI-driven HTTP calls
- lightweight confidence and entropy tracking

## Quick start

Run the direct-file primer relay:

```bash
cd /mnt/data/axiomurgy_v0_3
python axiomurgy.py examples/primer_to_axioms.spell.json --approve publish
```

Run the MCP relay:

```bash
cd /mnt/data/axiomurgy_v0_3
python axiomurgy.py examples/primer_via_mcp.spell.json --approve stage
```

Run the OpenAPI rollback demo:

```bash
python adapters/mock_issue_server.py >/tmp/axiomurgy_issue_server.log 2>&1 &
cd /mnt/data/axiomurgy_v0_3
python axiomurgy.py examples/openapi_ticket_then_fail.spell.json --approve create_ticket
```

That final command is expected to fail intentionally after the write and then compensate the ticket.
