# Axiomurgy Primer Codex

### Recurring themes
- (no stable themes extracted)

## Source 1
- ../primers/primer_01.txt
## Source 2
- ../primers/primer_02.txt
## Source 3
- ../primers/primer_03.txt
## Source 4
- ../primers/primer_04.txt
## Source 5
- ../primers/primer_05.txt
## Source 6
- ../primers/primer_06.txt
## Source 7
- ../primers/primer_07.txt

### Axiomurgy notes
- Strong systems benefit from explicit rules, social interpretation, and programmable forms.
- Conflicts become more interesting when the system rewards counters, verification, and creativity over raw power.
- A believable magical culture needs both the rules that work and the rituals people merely believe work.