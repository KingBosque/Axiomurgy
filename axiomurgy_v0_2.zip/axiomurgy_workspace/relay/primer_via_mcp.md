# Synthesized Brief

### Recurring themes
- rules and limits
- magic as culture
- science and programmability
- problem solving over power scaling
- meta systems and protocols

## Source 1
- 0:00Fantasy is full of worlds where people believe in magic, who use magic, like Graeme the wizard who likes cats. People accept magic as an indisputable fact,
- 0:099 secondswhich is interesting because for most of human history, this has also been the case, but often not the way we like to portray it in fantasy. I talk about
- 0:1717 secondswriting and world building in fantasy because uh it's my job, but I wrote a bunch of books on it. And you can actually pick these up at the link down below if you like these videos and you
- 0:2626 secondswant to learn more, or you can scan the QR code on screen right now. It's pretty cool. I get to sponsor my videos with my stuff because of you. In fantasy, we can
## Source 2
- Chapter 1: Intro
- 0:00magic magic magic magic magic magic magic magic magic it's not magic it's
- 0:077 secondswater bending today we are talking about magic and more specifically magic systems and how the heck you craft one
- 0:1515 secondsfirst of all what even is a magic system well it's any Supernatural element to your story that is different than our own world this can be an ability that
## Source 3
- 0:00it feels like it's been a while since I've really enjoyed a piece of high fantasy which makes me sad because I
- 0:077 secondsreally used to like this stuff I do still like the sense of wonder it provides the ideas are still good the stories are still interesting the more I
- 0:1616 secondslearn about magic and its history the less I see it in these stories in fact some of this stuff in a weird way makes
- 0:2525 secondsme feel something kind of opposite magic as if the actual IDE a of this fictional magic the fantasy we're all engaging in
## Source 4
- 0:00hey you you ever think about magic in media it's kind of everywhere and it's not always what it looks like there's obvious examples like Harry Potter has
- 0:088 secondsmagic what a shock but lightsabers magic chakra and Naruto magic the sword fighting in Demon Slayer actually maybe
- 0:1616 secondsnot magic but also kind of magic depending on how you define it just not in the way that it seems yeah that one's confusing but what differentiates a good
- 0:2424 secondsfrom a bad magic system in a show or movie Mostly whether or not it does its job but that's where things get complicated my name is pay and today
## Source 5
- Chapter 1: Intro
- 0:00How do you make a magic world from scratch? Unlike stories that follow the usual formula or series that do magic with a spin, Witchhat Attelier
- 0:088 secondscompletely reinvents the very concept of magic. Series creator Kam Shiramama borrows some of the usual tropes, but
- 0:1616 secondsshe also created a brand new magic system that feels less like sorcery and more like a practice of science. But
## Source 6
- Chapter 1: Intro
- 0:088 seconds﻿Intro*eyes* Magic Marvel idea   Magic is wonder, Magic is fantasy, its  power, its emotions, it is Hope.
- 0:1616 secondsMagic has become so synonymous with fantasy  that it's almost strange to see fantasy   worlds without it. And yet it doesn't feel  overused or unrealistic. I aim to accurately
- 0:2525 secondsincorporate magic into my fantasy world, and to  ensure I'm on the right track I plan to study   from previous media that has inspired me. This video I'll be going over what I think makes
## Source 7
- Type 1
- Every type of power system explained,
- including number six, a category I've
- never seen anyone discuss before. Number