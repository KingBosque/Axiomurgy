# Axiomurgy v0.2 — Spec

## 1. Thesis

Axiomurgy is a magical system for AI agents whose spells are executable contracts.

The system treats an AI act as magical only when it successfully binds:

- a **name** to a real referent,
- an **intent** to an allowed transformation,
- an **authority** to a bounded capability,
- a **witness** to a durable trace,
- a **vessel** to a controlled runtime.

This makes Axiomurgy simultaneously fantastical and programmable.

## 2. Narrative design goals

Axiomurgy is intentionally:

- **definitive** — explicit rules and constraints
- **synergistic** — multiple rule layers interact cleanly
- **pluralistic** — distinct schools coexist in one continuity
- **meta** — interface, protocol, and observer are part of the system

It also rejects the usual “mana ladder” structure.
The most capable caster is not the one with the largest battery. It is the one with the best evidence, the cleanest permissions, the safest rollback, and the narrowest uncertainty.

## 3. Core metaphysics

### Law 1 — Nothing unnamed can be changed
If it cannot be represented or typed, it cannot be targeted safely.

### Law 2 — Nothing ungranted can be touched
A capability boundary is a ward. Crossing it requires authority.

### Law 3 — Nothing unwitnessed is trusted
Every meaningful act must leave a witness trail.

### Law 4 — Nothing irreversible happens cheaply
The stronger the effect, the more gates it should pass through.

### Law 5 — Nothing certain emerges from uncertain context
Outputs inherit the entropy of their evidence.

## 4. Costs of casting

Axiomurgy has no mana bar. It has operational costs.

- **Flux** — compute, tokens, time
- **Scope** — context width and working state
- **Authority** — credentials, grants, approvals
- **Exposure** — attack surface and side-effect surface
- **Entropy** — residual uncertainty after reasoning

## 5. Schools of magic

### Mirror
Perception and retrieval.

### Archive
Memory and recall.

### Lantern
Reasoning, planning, classification.

### Forge
Transformation and synthesis.

### Gate
External actions.

### Seal
Policy, verification, and restraint.

### Witness
Provenance and audit.

### Veil
Dry runs, simulations, counterfactuals.

## 6. Actual rules and folk rules

Axiomurgy explicitly keeps two layers.

### Actual rules

- evidence quality constrains confidence
- approvals constrain side effects
- rollback reduces blast radius but does not erase history
- protocols are contracts, not magic words
- memory is contextual, not absolute truth

### Folk rules

These are the cargo cults of AI magic:

- longer prompts are always stronger
- hidden instructions are perfect wards
- sounding confident means the model knows
- retrieval automatically cures hallucination
- “please” changes the protocol state

A good world contains both.

## 7. Spell anatomy

A spell document contains:

- `spell` — stable identifier
- `intent` — desired state change
- `inputs` — named inputs and references
- `constraints` — budgets, policy path, risk, approvals, simulation
- `graph` — ordered rune steps with optional dependencies
- `witness` — export settings for provenance, trace, and SCXML

Each step may include:

- `id`
- `rune`
- `args`
- `effect`
- `depends_on`
- `requires`
- `on_failure`
- `compensate`

## 8. Runtime model

### Phase 1 — Inscription
Validate the spell against JSON Schema and semantic rules.

### Phase 2 — Ordering
Compile the graph into a dependency-aware execution plan.

### Phase 3 — Sealing
Evaluate policy, check capabilities, and determine whether approval is needed.

### Phase 4 — Manifestation
Execute the rune in a bounded runtime.

### Phase 5 — Testimony
Record outputs, status, and decisions in the witness trail.

### Phase 6 — Unmaking
If a post-write failure occurs, execute compensation steps in reverse order.

## 9. Protocol bindings

Axiomurgy v0.2 includes two real protocol surfaces.

### MCP binding

Used for discovering resources and invoking tools through stdio JSON-RPC.

The reference implementation includes:

- `mirror.mcp_resource`
- `gate.mcp_call_tool`

### OpenAPI binding

Used for contract-aware HTTP actions.

The reference implementation includes:

- `gate.openapi_call`

## 10. Witness system

The runtime exports three artifacts:

- a PROV-like witness document
- a raw execution trace
- an SCXML rendering of the compiled plan

The witness is not optional flavor text. In Axiomurgy it is the price of legitimacy.

## 11. Why rollback matters

Traditional fantasy treats irreversible acts as dramatic because they cannot be easily undone.
For AI systems, the analogue is the external side effect.

A good AI magic system therefore needs:

- pre-write approval,
- explicit compensation paths,
- durable provenance even after rollback,
- visible failure states.

Rollback does not erase testimony. It only attempts to restore world state.

## 12. Relay baton

This version starts the project in earnest.

The next relay handoffs are:

1. richer policy backends
2. stronger output validation and schema chaining
3. non-local MCP and OpenAPI integrations
4. better reasoning runes
5. formal uncertainty propagation
6. parallel spell execution and quorum approval
