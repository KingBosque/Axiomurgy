#!/usr/bin/env python3
"""Axiomurgy v0.2 reference runtime.

This runtime treats every spell as a typed, policy-gated, provenance-bearing
workflow. It upgrades the earlier v0.1 sketch with:

- JSON Schema validation (Draft 2020-12)
- dependency-aware execution planning
- policy decisions and human approval gates
- rollback / compensation actions for side effects
- provenance and trace export
- SCXML export of the compiled plan
- MCP stdio integration (resources + tools)
- OpenAPI-based HTTP calls

Usage:
    python axiomurgy.py examples/primer_to_axioms.spell.json
    python axiomurgy.py examples/primer_via_mcp.spell.json --approve publish
    python axiomurgy.py examples/openapi_ticket_then_fail.spell.json --approve create_ticket
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import traceback
import uuid
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple
from urllib.parse import urlencode

import requests
import yaml
from jsonschema import Draft202012Validator


VERSION = "0.2.0"
MCP_PROTOCOL_VERSION = "2025-06-18"
RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


class AxiomurgyError(Exception):
    """Base error."""


class SpellValidationError(AxiomurgyError):
    pass


class CapabilityError(AxiomurgyError):
    pass


class ApprovalRequiredError(AxiomurgyError):
    pass


class PolicyDeniedError(AxiomurgyError):
    pass


class StepExecutionError(AxiomurgyError):
    pass


class JsonRpcError(AxiomurgyError):
    pass


@dataclass
class Compensation:
    rune: str
    args: Dict[str, Any] = field(default_factory=dict)
    effect: str = "write"


@dataclass
class Step:
    step_id: str
    rune: str
    args: Dict[str, Any] = field(default_factory=dict)
    requires: List[str] = field(default_factory=list)
    effect: str = "transform"
    depends_on: List[str] = field(default_factory=list)
    on_failure: str = "rollback"
    compensate: Optional[Compensation] = None


@dataclass
class Spell:
    name: str
    intent: str
    inputs: Dict[str, Any]
    constraints: Dict[str, Any]
    graph: List[Step]
    witness: Dict[str, Any]
    source_path: Path


@dataclass
class PolicyDecision:
    allowed: bool = True
    requires_approval: bool = False
    approved: bool = False
    simulated: bool = False
    reasons: List[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        if not self.allowed:
            return "denied"
        if self.requires_approval and not self.approved:
            return "pending_approval"
        return "approved"


@dataclass
class ExecutionEvent:
    step_id: str
    rune: str
    effect: str
    status: str
    started_at: str
    ended_at: str
    args: Dict[str, Any]
    output_preview: str = ""
    error: Optional[str] = None
    policy: Dict[str, Any] = field(default_factory=dict)
    compensation_for: Optional[str] = None
    compensation_ran: bool = False


@dataclass
class CompensationRecord:
    step_id: str
    rune: str
    status: str
    started_at: str
    ended_at: str
    output_preview: str
    error: Optional[str] = None


RuneHandler = Callable[["RuneContext", Dict[str, Any]], Any]


class RuneRegistry:
    def __init__(self) -> None:
        self._handlers: Dict[str, RuneHandler] = {}
        self._capability_map: Dict[str, str] = {}

    def register(self, name: str, capability: str) -> Callable[[RuneHandler], RuneHandler]:
        def decorator(func: RuneHandler) -> RuneHandler:
            self._handlers[name] = func
            self._capability_map[name] = capability
            return func

        return decorator

    def handler_for(self, name: str) -> RuneHandler:
        if name not in self._handlers:
            raise KeyError(f"Unknown rune: {name}")
        return self._handlers[name]

    def required_capability(self, name: str) -> str:
        return self._capability_map[name]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha256_of(value: Any) -> str:
    if isinstance(value, bytes):
        data = value
    else:
        data = stable_json(value).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def preview_of(value: Any, limit: int = 240) -> str:
    text = repr(value)
    if len(text) > limit:
        return text[: limit - 3] + "..."
    return text


def load_document(path: Path) -> Any:
    suffix = path.suffix.lower()
    text = path.read_text(encoding="utf-8")
    if suffix in {".yaml", ".yml"}:
        return yaml.safe_load(text)
    return json.loads(text)


def dump_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def resolve_internal_ref(document: Dict[str, Any], ref: str) -> Any:
    if not ref.startswith("#/"):
        raise ValueError(f"Only internal refs are supported in the reference runtime: {ref}")
    current: Any = document
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        current = current[part]
    return current


def render_scxml(spell: Spell, ordered_steps: List[Step]) -> str:
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<scxml xmlns="http://www.w3.org/2005/07/scxml" version="1.0" initial="state_0" name="%s">'
        % spell.name,
    ]
    for idx, step in enumerate(ordered_steps):
        state_id = f"state_{idx}"
        next_state = f"state_{idx + 1}" if idx + 1 < len(ordered_steps) else "done"
        lines.append(f'  <state id="{state_id}">')
        lines.append(f'    <onentry><log label="{step.step_id}" expr="\'{step.rune}\'"/></onentry>')
        lines.append(f'    <transition event="success" target="{next_state}"/>')
        lines.append("  </state>")
    lines.append('  <final id="done"/>')
    lines.append("</scxml>")
    return "\n".join(lines) + "\n"


class JsonRpcStdioSession:
    def __init__(self, command: Sequence[str]) -> None:
        self.command = list(command)
        self.proc = subprocess.Popen(
            self.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            bufsize=1,
        )
        self._next_id = 1
        self.protocol_version = MCP_PROTOCOL_VERSION
        self.server_info: Dict[str, Any] = {}
        self.capabilities: Dict[str, Any] = {}
        self._initialize()

    def _write_message(self, payload: Dict[str, Any]) -> None:
        if self.proc.stdin is None:
            raise JsonRpcError("MCP stdin is not available")
        self.proc.stdin.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
        self.proc.stdin.flush()

    def _read_until_response(self, request_id: int) -> Dict[str, Any]:
        if self.proc.stdout is None:
            raise JsonRpcError("MCP stdout is not available")
        while True:
            line = self.proc.stdout.readline()
            if line == "":
                stderr_text = ""
                if self.proc.stderr is not None:
                    try:
                        stderr_text = self.proc.stderr.read()
                    except Exception:
                        stderr_text = ""
                raise JsonRpcError(f"MCP server terminated unexpectedly. stderr={stderr_text!r}")
            line = line.strip()
            if not line:
                continue
            try:
                message = json.loads(line)
            except json.JSONDecodeError as exc:
                raise JsonRpcError(f"Invalid JSON-RPC message: {line!r}") from exc
            if "id" not in message:
                continue
            if message.get("id") != request_id:
                continue
            return message

    def request(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        request_id = self._next_id
        self._next_id += 1
        payload: Dict[str, Any] = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            payload["params"] = params
        self._write_message(payload)
        message = self._read_until_response(request_id)
        if "error" in message:
            error = message["error"]
            raise JsonRpcError(f"{method} failed: {error.get('message', 'unknown error')}")
        return message.get("result")

    def notify(self, method: str, params: Optional[Dict[str, Any]] = None) -> None:
        payload: Dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        self._write_message(payload)

    def _initialize(self) -> None:
        result = self.request(
            "initialize",
            {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {"resources": {}, "tools": {}},
                "clientInfo": {"name": "axiomurgy", "version": VERSION},
            },
        )
        self.protocol_version = result.get("protocolVersion", MCP_PROTOCOL_VERSION)
        self.server_info = result.get("serverInfo", {})
        self.capabilities = result.get("capabilities", {})
        self.notify("notifications/initialized")

    def list_resources(self) -> Any:
        return self.request("resources/list", {})

    def read_resource(self, uri: str) -> Any:
        return self.request("resources/read", {"uri": uri})

    def list_tools(self) -> Any:
        return self.request("tools/list", {})

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        return self.request("tools/call", {"name": name, "arguments": arguments})

    def close(self) -> None:
        if self.proc.stdin is not None:
            try:
                self.proc.stdin.close()
            except Exception:
                pass
        if self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=2)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass


class RuneContext:
    def __init__(self, spell: Spell, capabilities: Optional[List[str]] = None, approvals: Optional[Iterable[str]] = None) -> None:
        self.spell = spell
        self.capabilities = set(capabilities or [])
        self.approvals = set(approvals or [])
        self.values: Dict[str, Any] = {"inputs": spell.inputs}
        self.events: List[ExecutionEvent] = []
        self.compensations: List[CompensationRecord] = []
        self.compensation_stack: List[Tuple[str, Compensation]] = []
        self.mcp_sessions: Dict[str, JsonRpcStdioSession] = {}
        self.started_at = utc_now()
        self.execution_id = str(uuid.uuid4())
        self.policy_document = self._load_policy_document()
        self.simulate_only = bool(spell.constraints.get("simulate_only", False))

    def _load_policy_document(self) -> Dict[str, Any]:
        policy_ref = self.spell.constraints.get("policy")
        if not policy_ref:
            return {}
        policy_path = self.resolve_path(str(policy_ref))
        if not policy_path.exists():
            raise SpellValidationError(f"Policy file does not exist: {policy_path}")
        document = load_document(policy_path)
        if not isinstance(document, dict):
            raise SpellValidationError("Policy document must be an object")
        return document

    def resolve_path(self, path_like: str) -> Path:
        candidate = Path(path_like)
        if candidate.is_absolute():
            return candidate
        return (self.spell.source_path.parent / candidate).resolve()

    def resolve_ref(self, ref: str) -> Any:
        parts = ref.split(".")
        root = parts[0]
        if root == "env":
            current: Any = os.environ
        elif root == "inputs":
            current = self.values["inputs"]
        elif root in self.values:
            current = self.values[root]
        else:
            raise KeyError(f"Unknown reference: ${ref}")
        for part in parts[1:]:
            if isinstance(current, dict):
                if part not in current:
                    raise KeyError(f"Unknown reference: ${ref}")
                current = current[part]
            elif isinstance(current, list):
                if not part.isdigit():
                    raise KeyError(f"Unknown list reference: ${ref}")
                current = current[int(part)]
            else:
                if not hasattr(current, part):
                    raise KeyError(f"Unknown attribute reference: ${ref}")
                current = getattr(current, part)
        return current

    def resolve_string(self, value: str) -> Any:
        if re.fullmatch(r"\$[A-Za-z_][A-Za-z0-9_\-.]*", value):
            return self.resolve_ref(value[1:])

        def replace(match: re.Match[str]) -> str:
            ref = match.group(1)
            return str(self.resolve_ref(ref))

        if "${" in value:
            return re.sub(r"\$\{([^}]+)\}", replace, value)
        return value

    def resolve(self, value: Any) -> Any:
        if isinstance(value, str):
            return self.resolve_string(value)
        if isinstance(value, list):
            return [self.resolve(item) for item in value]
        if isinstance(value, dict):
            return {key: self.resolve(item) for key, item in value.items()}
        return value

    def get_mcp_session(self, server: str) -> JsonRpcStdioSession:
        path = str(self.resolve_path(server))
        if path not in self.mcp_sessions:
            self.mcp_sessions[path] = JsonRpcStdioSession([sys.executable, path])
        return self.mcp_sessions[path]

    def close(self) -> None:
        for session in self.mcp_sessions.values():
            session.close()


REGISTRY = RuneRegistry()


@REGISTRY.register("mirror.read", capability="read")
def rune_mirror_read(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    source = args.get("input")
    if source is None:
        raise ValueError("mirror.read requires an 'input' argument")
    source = ctx.resolve(source)

    def read_one(item: Any) -> str:
        if isinstance(item, str) and item.startswith("file://"):
            path = Path(item[7:])
            return path.read_text(encoding="utf-8")
        if isinstance(item, str) and item.startswith("/"):
            return Path(item).read_text(encoding="utf-8")
        return str(item)

    if isinstance(source, list):
        return [read_one(item) for item in source]
    return read_one(source)


@REGISTRY.register("mirror.mcp_resource", capability="read")
def rune_mirror_mcp_resource(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    server = str(ctx.resolve(args.get("server")))
    uris = ctx.resolve(args.get("uri"))
    if not server:
        raise ValueError("mirror.mcp_resource requires a server path")
    session = ctx.get_mcp_session(server)
    if isinstance(uris, list):
        results = []
        for uri in uris:
            result = session.read_resource(str(uri))
            results.append(result)
        return results
    return session.read_resource(str(uris))


@REGISTRY.register("archive.retrieve", capability="memory")
def rune_archive_retrieve(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    key = str(ctx.resolve(args.get("key", "")))
    return {
        "memory_key": key,
        "note": f"No external memory backend attached for '{key}'. Returning placeholder memory.",
    }


@REGISTRY.register("lantern.classify", capability="reason")
def rune_lantern_classify(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    items = ctx.resolve(args.get("items", []))
    if not isinstance(items, list):
        items = [items]
    labels = []
    for item in items:
        text = str(item).lower()
        if any(word in text for word in ["urgent", "asap", "immediately", "today"]):
            label = "urgent"
        elif any(word in text for word in ["invoice", "receipt", "payment"]):
            label = "finance"
        else:
            label = "normal"
        labels.append({"text": item, "label": label})
    return labels


@REGISTRY.register("forge.summarize", capability="transform")
def rune_forge_summarize(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    content = ctx.resolve(args.get("from", ""))
    texts: List[str]
    if isinstance(content, list):
        texts = []
        for item in content:
            if isinstance(item, dict) and "contents" in item:
                for block in item.get("contents", []):
                    if isinstance(block, dict) and "text" in block:
                        texts.append(str(block["text"]))
                    else:
                        texts.append(stable_json(block))
            else:
                texts.append(str(item))
    else:
        texts = [str(content)]

    sections: List[str] = []
    for idx, text in enumerate(texts, start=1):
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        head = lines[:4] if lines else [text[:200].strip() or "(empty)"]
        sections.append(f"## Source {idx}\n- " + "\n- ".join(head[:4]))

    lower = "\n".join(texts).lower()
    themes = []
    keyword_map = {
        "rules and limits": ["rule", "limit", "constraint", "hard magic", "definitive"],
        "magic as culture": ["belief", "superstition", "culture", "messy magical belief"],
        "science and programmability": ["science", "code", "coding", "rune", "program"],
        "problem solving over power scaling": ["problem", "power scale", "mana", "creative"],
        "meta systems and protocols": ["meta", "protocol", "system", "tool"],
    }
    for label, keys in keyword_map.items():
        if any(key in lower for key in keys):
            themes.append(label)

    output = ["# Synthesized Brief", "", "### Recurring themes"]
    for theme in themes or ["typed workflows", "witnessed execution", "belief versus reality"]:
        output.append(f"- {theme}")
    output.append("")
    output.extend(sections)
    return "\n".join(output)


@REGISTRY.register("forge.template", capability="transform")
def rune_forge_template(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    template = str(args.get("template", ""))
    bindings = ctx.resolve(args.get("bindings", {}))
    if not isinstance(bindings, dict):
        raise ValueError("forge.template requires object bindings")
    try:
        return template.format(**bindings)
    except KeyError as exc:
        raise ValueError(f"Missing template binding: {exc}") from exc


@REGISTRY.register("forge.reply_drafts", capability="transform")
def rune_forge_reply_drafts(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    items = ctx.resolve(args.get("items", []))
    if not isinstance(items, list):
        items = [items]
    drafts = []
    for item in items:
        if isinstance(item, dict):
            text = str(item.get("text", ""))
            label = str(item.get("label", "normal"))
        else:
            text = str(item)
            label = "normal"
        if label == "urgent":
            reply = "Acknowledged. I have flagged this as urgent and prepared it for immediate human review."
        elif label == "finance":
            reply = "Thanks. I have routed this to the finance queue and prepared a draft response for confirmation."
        else:
            reply = "Thanks for the message. I have prepared a brief reply draft for review."
        drafts.append({"original": text, "label": label, "draft": reply})
    return drafts


@REGISTRY.register("seal.review", capability="verify")
def rune_seal_review(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    artifact = ctx.resolve(args.get("from"))
    required_markers = args.get("must_include", [])
    text = artifact if isinstance(artifact, str) else stable_json(artifact)
    missing = [marker for marker in required_markers if marker not in text]
    return {
        "approved": not missing,
        "missing": missing,
        "artifact": artifact,
        "note": "Minimal review. Replace with richer policy and citation checks in production.",
    }


@REGISTRY.register("seal.require", capability="verify")
def rune_seal_require(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    value = ctx.resolve(args.get("value"))
    expected = ctx.resolve(args.get("equals")) if "equals" in args else None
    message = str(args.get("message", "seal.require failed"))
    if "equals" in args:
        ok = value == expected
    else:
        ok = bool(value)
    if not ok:
        raise ValueError(message)
    return {"ok": True, "value": value}


@REGISTRY.register("seal.approval_gate", capability="approve")
def rune_seal_approval_gate(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    reason = str(ctx.resolve(args.get("reason", "")))
    auto = bool(args.get("auto_approve", False))
    return {
        "approved": auto,
        "reason": reason,
        "status": "approved" if auto else "pending_human_review",
    }


@REGISTRY.register("veil.simulate", capability="simulate")
def rune_veil_simulate(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    artifact = ctx.resolve(args.get("from"))
    return {
        "simulated": True,
        "preview": artifact,
        "note": "Dry-run only; no external side effects were committed.",
    }


@REGISTRY.register("gate.archive", capability="write")
def rune_gate_archive(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    artifact = ctx.resolve(args.get("from"))
    count = len(artifact) if isinstance(artifact, list) else 1
    if ctx.simulate_only:
        return {"archived": count, "status": "simulated_archive"}
    return {"archived": count, "status": "archive_marked"}


@REGISTRY.register("gate.emit", capability="write")
def rune_gate_emit(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    artifact = ctx.resolve(args.get("from"))
    target = str(ctx.resolve(args.get("target", "stdout")))
    if ctx.simulate_only:
        return {"target": target, "emitted": artifact, "status": "simulated_write"}
    return {"target": target, "emitted": artifact, "status": "written"}


@REGISTRY.register("gate.file_write", capability="write")
def rune_gate_file_write(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    path_value = args.get("path")
    if path_value is None:
        raise ValueError("gate.file_write requires a path")
    content = ctx.resolve(args.get("from", ""))
    path = ctx.resolve_path(str(ctx.resolve(path_value)))
    mode = str(args.get("mode", "text"))
    path.parent.mkdir(parents=True, exist_ok=True)
    if ctx.simulate_only:
        return {
            "path": str(path),
            "mode": mode,
            "bytes": len(str(content).encode("utf-8")),
            "status": "simulated_write",
        }
    if mode == "json":
        dump_json(path, content)
    else:
        path.write_text(str(content), encoding="utf-8")
    size = path.stat().st_size
    return {
        "path": str(path),
        "mode": mode,
        "bytes": size,
        "sha256": sha256_of(path.read_bytes()),
        "status": "written",
    }


@REGISTRY.register("gate.file_delete", capability="write")
def rune_gate_file_delete(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    path_value = args.get("path")
    if path_value is None:
        raise ValueError("gate.file_delete requires a path")
    path = ctx.resolve_path(str(ctx.resolve(path_value)))
    if ctx.simulate_only:
        return {"path": str(path), "deleted": False, "status": "simulated_delete"}
    existed = path.exists()
    if existed:
        path.unlink()
    return {"path": str(path), "deleted": existed, "status": "deleted" if existed else "already_absent"}


@REGISTRY.register("gate.mcp_call_tool", capability="write")
def rune_gate_mcp_call_tool(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    server = str(ctx.resolve(args.get("server")))
    name = str(ctx.resolve(args.get("name")))
    arguments = ctx.resolve(args.get("arguments", {}))
    if ctx.simulate_only:
        return {
            "server": server,
            "tool": name,
            "arguments": arguments,
            "status": "simulated_mcp_call",
        }
    session = ctx.get_mcp_session(server)
    return session.call_tool(name, arguments)


@REGISTRY.register("gate.openapi_call", capability="write")
def rune_gate_openapi_call(ctx: RuneContext, args: Dict[str, Any]) -> Any:
    spec_ref = args.get("spec")
    operation_id = str(ctx.resolve(args.get("operationId")))
    if spec_ref is None:
        raise ValueError("gate.openapi_call requires a spec path")
    spec_path = ctx.resolve_path(str(ctx.resolve(spec_ref)))
    spec = load_document(spec_path)
    if not isinstance(spec, dict):
        raise ValueError("OpenAPI spec must be a mapping")

    match: Optional[Tuple[str, str, Dict[str, Any]]] = None
    for raw_path, item in spec.get("paths", {}).items():
        if not isinstance(item, dict):
            continue
        for method, operation in item.items():
            if method.lower() not in {"get", "post", "put", "patch", "delete"}:
                continue
            if isinstance(operation, dict) and operation.get("operationId") == operation_id:
                match = (method.upper(), raw_path, operation)
                break
        if match:
            break
    if match is None:
        raise ValueError(f"operationId not found in OpenAPI spec: {operation_id}")

    method, raw_path, operation = match
    arguments = ctx.resolve(args.get("arguments", {}))
    if not isinstance(arguments, dict):
        raise ValueError("gate.openapi_call arguments must resolve to an object")

    servers = spec.get("servers") or [{"url": "http://127.0.0.1:8942"}]
    default_server = str((servers[0] or {}).get("url", "http://127.0.0.1:8942"))
    base_url = str(ctx.resolve(args.get("server", default_server)))
    allow_remote_http = bool(ctx.spell.constraints.get("allow_remote_http", False))
    if not allow_remote_http and not (
        base_url.startswith("http://127.0.0.1")
        or base_url.startswith("http://localhost")
        or base_url.startswith("https://127.0.0.1")
        or base_url.startswith("https://localhost")
    ):
        raise ValueError(
            "Reference runtime only allows localhost HTTP targets unless allow_remote_http=true"
        )

    path_params = dict(arguments.get("path", {}))
    query_params = dict(arguments.get("query", {}))
    headers = dict(arguments.get("headers", {}))
    body = arguments.get("body")

    rendered_path = raw_path
    for segment in re.findall(r"\{([^}]+)\}", raw_path):
        if segment not in path_params:
            raise ValueError(f"Missing path parameter: {segment}")
        rendered_path = rendered_path.replace("{" + segment + "}", str(path_params[segment]))

    all_parameters = []
    if isinstance(spec.get("paths", {}).get(raw_path), dict):
        all_parameters.extend(spec["paths"][raw_path].get("parameters", []))
    all_parameters.extend(operation.get("parameters", []))
    for parameter in all_parameters:
        if isinstance(parameter, dict) and "$ref" in parameter:
            parameter = resolve_internal_ref(spec, parameter["$ref"])
        if not isinstance(parameter, dict):
            continue
        if parameter.get("required"):
            location = parameter.get("in")
            name = parameter.get("name")
            source_map = path_params if location == "path" else query_params if location == "query" else headers
            if name not in source_map:
                raise ValueError(f"Missing required {location} parameter: {name}")

    request_body = operation.get("requestBody")
    if isinstance(request_body, dict) and "$ref" in request_body:
        request_body = resolve_internal_ref(spec, request_body["$ref"])
    if isinstance(request_body, dict) and request_body.get("required") and body is None:
        raise ValueError(f"Operation requires a body: {operation_id}")
    if isinstance(request_body, dict) and body is not None:
        content = request_body.get("content", {})
        media = content.get("application/json")
        if isinstance(media, dict):
            schema = media.get("schema")
            if isinstance(schema, dict) and "$ref" in schema:
                schema = resolve_internal_ref(spec, schema["$ref"])
            if isinstance(schema, dict):
                Draft202012Validator(schema).validate(body)

    url = base_url.rstrip("/") + rendered_path
    if query_params:
        url = url + "?" + urlencode(query_params, doseq=True)

    if ctx.simulate_only:
        return {
            "status": "simulated_http_call",
            "method": method,
            "url": url,
            "headers": headers,
            "body": body,
        }

    response = requests.request(method, url, headers=headers, json=body, timeout=10)
    try:
        response_body: Any = response.json()
    except ValueError:
        response_body = response.text
    return {
        "status": "http_call_complete",
        "method": method,
        "url": url,
        "status_code": response.status_code,
        "body": response_body,
    }


def collect_refs(value: Any) -> Set[str]:
    found: Set[str] = set()
    if isinstance(value, str):
        full_match = re.fullmatch(r"\$([A-Za-z_][A-Za-z0-9_\-.]*)", value)
        if full_match:
            found.add(full_match.group(1))
        for match in re.finditer(r"\$\{([^}]+)\}", value):
            found.add(match.group(1))
        return found
    if isinstance(value, list):
        for item in value:
            found |= collect_refs(item)
        return found
    if isinstance(value, dict):
        for item in value.values():
            found |= collect_refs(item)
        return found
    return found


def validate_spell_document(doc: Dict[str, Any], schema: Dict[str, Any], source_path: Path) -> Spell:
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(doc), key=lambda exc: list(exc.path))
    if errors:
        message = "; ".join(f"{'/'.join(str(x) for x in err.path) or '<root>'}: {err.message}" for err in errors)
        raise SpellValidationError(message)

    step_ids: Set[str] = set()
    steps: List[Step] = []
    for raw_step in doc["graph"]:
        step_id = raw_step["id"]
        if step_id in step_ids:
            raise SpellValidationError(f"Duplicate step id: {step_id}")
        step_ids.add(step_id)
        compensate: Optional[Compensation] = None
        if "compensate" in raw_step and raw_step["compensate"] is not None:
            comp = raw_step["compensate"]
            compensate = Compensation(
                rune=comp["rune"],
                args=comp.get("args", {}),
                effect=comp.get("effect", "write"),
            )
        steps.append(
            Step(
                step_id=step_id,
                rune=raw_step["rune"],
                args=raw_step.get("args", {}),
                requires=raw_step.get("requires", []),
                effect=raw_step.get("effect", "transform"),
                depends_on=raw_step.get("depends_on", []),
                on_failure=raw_step.get("on_failure", "rollback"),
                compensate=compensate,
            )
        )

    valid_roots = {"inputs", "env"} | step_ids
    for step in steps:
        for ref in collect_refs(step.args):
            root = ref.split(".")[0]
            if root not in valid_roots:
                raise SpellValidationError(f"Unknown reference in step '{step.step_id}': ${ref}")
        if step.compensate is not None:
            for ref in collect_refs(step.compensate.args):
                root = ref.split(".")[0]
                if root not in valid_roots:
                    raise SpellValidationError(
                        f"Unknown reference in compensation for '{step.step_id}': ${ref}"
                    )
        for dependency in step.depends_on:
            if dependency not in step_ids:
                raise SpellValidationError(
                    f"Unknown dependency '{dependency}' in step '{step.step_id}'"
                )

    return Spell(
        name=doc["spell"],
        intent=doc["intent"],
        inputs=doc.get("inputs", {}),
        constraints=doc.get("constraints", {}),
        graph=steps,
        witness=doc.get("witness", {"record": True, "format": "prov-json"}),
        source_path=source_path,
    )


def build_execution_order(spell: Spell) -> List[Step]:
    ids = {step.step_id for step in spell.graph}
    order_index = {step.step_id: index for index, step in enumerate(spell.graph)}
    deps: Dict[str, Set[str]] = {step.step_id: set(step.depends_on) for step in spell.graph}
    reverse: Dict[str, Set[str]] = {step.step_id: set() for step in spell.graph}
    for step in spell.graph:
        for ref in collect_refs(step.args):
            root = ref.split(".")[0]
            if root in ids and root != step.step_id:
                deps[step.step_id].add(root)
        if step.step_id in deps[step.step_id]:
            raise SpellValidationError(f"Step '{step.step_id}' cannot depend on itself")
        for dep in deps[step.step_id]:
            reverse[dep].add(step.step_id)

    ready = deque(sorted((step_id for step_id, pending in deps.items() if not pending), key=order_index.get))
    ordered_ids: List[str] = []
    while ready:
        current = ready.popleft()
        ordered_ids.append(current)
        for successor in sorted(reverse[current], key=order_index.get):
            deps[successor].remove(current)
            if not deps[successor]:
                ready.append(successor)
    if len(ordered_ids) != len(spell.graph):
        unresolved = [step_id for step_id, pending in deps.items() if pending]
        raise SpellValidationError(f"Dependency cycle detected involving: {sorted(unresolved)}")
    by_id = {step.step_id: step for step in spell.graph}
    return [by_id[step_id] for step_id in ordered_ids]


def evaluate_policy(ctx: RuneContext, step: Step) -> PolicyDecision:
    decision = PolicyDecision()
    spell_risk = str(ctx.spell.constraints.get("risk", "medium"))

    raw_requires = ctx.spell.constraints.get("requires_approval_for", [])
    if not isinstance(raw_requires, list):
        raw_requires = []
    if step.effect in raw_requires or step.rune in raw_requires:
        decision.requires_approval = True
        decision.reasons.append("Spell constraints explicitly require approval for this step.")

    if step.effect == "write" and RISK_ORDER[spell_risk] >= RISK_ORDER["high"]:
        decision.requires_approval = True
        decision.reasons.append("High-risk write steps require approval.")

    policy_doc = ctx.policy_document
    for rule in policy_doc.get("deny", []):
        if rule_matches(rule, spell_risk, step):
            decision.allowed = False
            decision.reasons.append(str(rule.get("reason", "Denied by policy.")))
    for rule in policy_doc.get("requires_approval", []):
        if rule_matches(rule, spell_risk, step):
            decision.requires_approval = True
            decision.reasons.append(str(rule.get("reason", "Approval required by policy.")))

    if ctx.simulate_only and step.effect == "write":
        decision.simulated = True
        decision.reasons.append("Simulation mode is active; write effects are non-destructive.")

    if decision.requires_approval:
        decision.approved = (
            step.step_id in ctx.approvals
            or step.rune in ctx.approvals
            or "all" in ctx.approvals
        )
    else:
        decision.approved = True
    return decision


def rule_matches(rule: Dict[str, Any], spell_risk: str, step: Step) -> bool:
    if not isinstance(rule, dict):
        return False
    if "effect" in rule and step.effect not in set(rule.get("effect", [])):
        return False
    if "rune" in rule and step.rune not in set(rule.get("rune", [])):
        return False
    if "min_risk" in rule and RISK_ORDER[spell_risk] < RISK_ORDER[str(rule["min_risk"])]:
        return False
    if "max_risk" in rule and RISK_ORDER[spell_risk] > RISK_ORDER[str(rule["max_risk"])]:
        return False
    return True


def append_event(ctx: RuneContext, event: ExecutionEvent) -> None:
    ctx.events.append(event)


def maybe_export_witness(spell: Spell, ordered_steps: List[Step], ctx: RuneContext, result: Dict[str, Any]) -> Dict[str, str]:
    outputs: Dict[str, str] = {}
    witness = spell.witness or {}
    if not witness.get("record", True):
        return outputs

    trace_document = {
        "spell": spell.name,
        "intent": spell.intent,
        "execution_id": ctx.execution_id,
        "started_at": ctx.started_at,
        "ended_at": utc_now(),
        "status": result.get("status"),
        "events": [asdict(event) for event in ctx.events],
        "compensations": [asdict(item) for item in ctx.compensations],
    }
    if witness.get("include_inputs", True):
        trace_document["inputs"] = spell.inputs

    prov_document = build_prov_document(spell, ctx)

    if witness.get("trace_path"):
        trace_path = ctx.resolve_path(str(witness["trace_path"]))
        dump_json(trace_path, trace_document)
        outputs["trace_path"] = str(trace_path)
    if witness.get("path"):
        witness_path = ctx.resolve_path(str(witness["path"]))
        if str(witness.get("format", "prov-json")) == "trace":
            dump_json(witness_path, trace_document)
        else:
            dump_json(witness_path, prov_document)
        outputs["witness_path"] = str(witness_path)
    if witness.get("scxml_path"):
        scxml_path = ctx.resolve_path(str(witness["scxml_path"]))
        scxml_path.parent.mkdir(parents=True, exist_ok=True)
        scxml_path.write_text(render_scxml(spell, ordered_steps), encoding="utf-8")
        outputs["scxml_path"] = str(scxml_path)
    return outputs


def build_prov_document(spell: Spell, ctx: RuneContext) -> Dict[str, Any]:
    activity: Dict[str, Any] = {}
    entity: Dict[str, Any] = {}
    used: Dict[str, Any] = {}
    was_generated_by: Dict[str, Any] = {}
    was_derived_from: Dict[str, Any] = {}

    spell_entity_id = f"entity:spell:{spell.name}"
    entity[spell_entity_id] = {
        "prov:label": spell.name,
        "axiom:intent": spell.intent,
        "axiom:source": str(spell.source_path),
    }

    for index, event in enumerate(ctx.events, start=1):
        activity_id = f"activity:{event.step_id}"
        entity_id = f"entity:{event.step_id}:output"
        activity[activity_id] = {
            "prov:startTime": event.started_at,
            "prov:endTime": event.ended_at,
            "prov:type": event.rune,
            "axiom:status": event.status,
            "axiom:effect": event.effect,
        }
        entity[entity_id] = {
            "prov:label": event.step_id,
            "axiom:output_preview": event.output_preview,
            "axiom:status": event.status,
        }
        used[f"used:{index}"] = {
            "prov:activity": activity_id,
            "prov:entity": spell_entity_id,
        }
        was_generated_by[f"generated:{index}"] = {
            "prov:entity": entity_id,
            "prov:activity": activity_id,
        }
        if index > 1:
            prev_entity_id = f"entity:{ctx.events[index - 2].step_id}:output"
            was_derived_from[f"derived:{index}"] = {
                "prov:generatedEntity": entity_id,
                "prov:usedEntity": prev_entity_id,
            }

    return {
        "prefix": {"prov": "http://www.w3.org/ns/prov#", "axiom": "urn:axiomurgy:"},
        "entity": entity,
        "activity": activity,
        "agent": {
            "agent:axiomurgy": {
                "prov:type": "prov:SoftwareAgent",
                "prov:label": "Axiomurgy runtime",
                "axiom:version": VERSION,
            }
        },
        "used": used,
        "wasGeneratedBy": was_generated_by,
        "wasDerivedFrom": was_derived_from,
    }


def run_compensation(ctx: RuneContext, compensation_for: str, compensation: Compensation) -> None:
    started_at = utc_now()
    status = "compensated"
    output_preview = ""
    error_text: Optional[str] = None
    try:
        handler = REGISTRY.handler_for(compensation.rune)
        resolved_args = ctx.resolve(compensation.args)
        output = handler(ctx, resolved_args)
        output_preview = preview_of(output)
    except Exception as exc:  # pragma: no cover - best effort cleanup
        status = "compensation_failed"
        error_text = str(exc)
        output_preview = preview_of({"error": str(exc)})
    ended_at = utc_now()
    ctx.compensations.append(
        CompensationRecord(
            step_id=compensation_for,
            rune=compensation.rune,
            status=status,
            started_at=started_at,
            ended_at=ended_at,
            output_preview=output_preview,
            error=error_text,
        )
    )


def execute_spell(spell: Spell, capabilities: Optional[List[str]] = None, approvals: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    ordered_steps = build_execution_order(spell)
    ctx = RuneContext(spell, capabilities=capabilities, approvals=approvals)

    try:
        required_capabilities = set(spell.constraints.get("required_capabilities", []))
        if not required_capabilities.issubset(ctx.capabilities):
            missing = sorted(required_capabilities - ctx.capabilities)
            raise CapabilityError(f"Missing spell-level capabilities: {missing}")

        for step in ordered_steps:
            started_at = utc_now()
            policy = evaluate_policy(ctx, step)
            event = ExecutionEvent(
                step_id=step.step_id,
                rune=step.rune,
                effect=step.effect,
                status="running",
                started_at=started_at,
                ended_at=started_at,
                args={},
                policy=asdict(policy),
            )
            try:
                rune_cap = REGISTRY.required_capability(step.rune)
                if rune_cap not in ctx.capabilities:
                    raise CapabilityError(
                        f"Step '{step.step_id}' requires capability '{rune_cap}' for rune '{step.rune}'"
                    )
                if step.requires:
                    missing_step_caps = sorted(set(step.requires) - ctx.capabilities)
                    if missing_step_caps:
                        raise CapabilityError(
                            f"Step '{step.step_id}' missing required capabilities {missing_step_caps}"
                        )
                if not policy.allowed:
                    raise PolicyDeniedError("; ".join(policy.reasons) or "Denied by policy")
                if policy.requires_approval and not policy.approved:
                    raise ApprovalRequiredError(
                        f"Step '{step.step_id}' awaits approval. Re-run with --approve {step.step_id}"
                    )

                resolved_args = ctx.resolve(step.args)
                event.args = resolved_args
                if policy.simulated:
                    original_simulation = ctx.simulate_only
                    ctx.simulate_only = True
                    try:
                        handler = REGISTRY.handler_for(step.rune)
                        output = handler(ctx, resolved_args)
                    finally:
                        ctx.simulate_only = original_simulation
                else:
                    handler = REGISTRY.handler_for(step.rune)
                    output = handler(ctx, resolved_args)
                ctx.values[step.step_id] = output
                if step.compensate is not None:
                    ctx.compensation_stack.append((step.step_id, step.compensate))
                event.status = "succeeded"
                event.output_preview = preview_of(output)
                event.ended_at = utc_now()
                append_event(ctx, event)
            except ApprovalRequiredError as exc:
                event.status = "awaiting_approval"
                event.error = str(exc)
                event.ended_at = utc_now()
                append_event(ctx, event)
                result = {
                    "spell": spell.name,
                    "intent": spell.intent,
                    "status": "awaiting_approval",
                    "pending_step": step.step_id,
                    "message": str(exc),
                    "events": [asdict(item) for item in ctx.events],
                }
                result.update(maybe_export_witness(spell, ordered_steps, ctx, result))
                return result
            except Exception as exc:
                event.status = "failed"
                event.error = str(exc)
                event.ended_at = utc_now()
                event.output_preview = preview_of({"error": str(exc)})
                append_event(ctx, event)
                if step.on_failure == "rollback":
                    for compensation_for, compensation in reversed(ctx.compensation_stack):
                        run_compensation(ctx, compensation_for, compensation)
                result = {
                    "spell": spell.name,
                    "intent": spell.intent,
                    "status": "failed",
                    "failed_step": step.step_id,
                    "error": str(exc),
                    "events": [asdict(item) for item in ctx.events],
                    "compensations": [asdict(item) for item in ctx.compensations],
                }
                result.update(maybe_export_witness(spell, ordered_steps, ctx, result))
                return result

        final_step_id = ordered_steps[-1].step_id
        result = {
            "spell": spell.name,
            "intent": spell.intent,
            "status": "succeeded",
            "final": ctx.values[final_step_id],
            "values": ctx.values,
            "events": [asdict(item) for item in ctx.events],
            "compensations": [asdict(item) for item in ctx.compensations],
        }
        result.update(maybe_export_witness(spell, ordered_steps, ctx, result))
        return result
    finally:
        ctx.close()


def load_spell(path: Path) -> Spell:
    document = load_document(path)
    if not isinstance(document, dict):
        raise SpellValidationError("Spell document must be a JSON or YAML object")
    schema_path = Path(__file__).with_name("spell.schema.json")
    schema = load_document(schema_path)
    if not isinstance(schema, dict):
        raise SpellValidationError("Spell schema must be an object")
    return validate_spell_document(document, schema, source_path=path.resolve())


def parse_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Execute an Axiomurgy spell.")
    parser.add_argument("spell", help="Path to a .json or .yaml spell file")
    parser.add_argument(
        "--approve",
        action="append",
        default=[],
        help="Grant approval for a specific step id, rune name, or 'all'. Repeatable.",
    )
    parser.add_argument(
        "--capabilities",
        default="read,memory,reason,transform,verify,approve,simulate,write",
        help="Comma-separated capability set for the runtime.",
    )
    return parser.parse_args(argv[1:])


def main(argv: List[str]) -> int:
    args = parse_args(argv)
    path = Path(args.spell)
    if not path.exists():
        print(f"ERROR: File not found: {path}")
        return 2

    capabilities = [item.strip() for item in args.capabilities.split(",") if item.strip()]

    try:
        spell = load_spell(path)
        result = execute_spell(spell, capabilities=capabilities, approvals=args.approve)
    except (AxiomurgyError, KeyError, ValueError, requests.RequestException, yaml.YAMLError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "fatal", "error": str(exc)}, indent=2, ensure_ascii=False))
        return 1
    except Exception as exc:  # pragma: no cover - defensive
        print(
            json.dumps(
                {"status": "fatal", "error": str(exc), "traceback": traceback.format_exc()},
                indent=2,
                ensure_ascii=False,
            )
        )
        return 1

    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result.get("status") == "succeeded" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
