# Axiomurgy v0.2

Axiomurgy is a programmable magical system for AIs.

A spell is not a vibe. It is a **typed, permissioned, provenance-bearing workflow**.
Instead of mana, it spends scope, authority, exposure, latency, and uncertainty.
Instead of wands, it uses schemas, protocols, tools, policies, and witnesses.

## What v0.2 adds

Compared with the earlier kickoff draft, v0.2 adds real runtime machinery:

- Draft 2020-12 JSON Schema validation for spells
- dependency-aware execution planning
- policy evaluation and human approval gates
- rollback / compensation semantics for side effects
- provenance export and raw execution traces
- SCXML plan export
- MCP stdio integration for resources and tools
- OpenAPI-driven HTTP calls

## Project structure

- `AXIOMURGY_SPEC.md` — design spec and metaphysics
- `spell.schema.json` — spell contract
- `axiomurgy.py` — runtime
- `policies/default.policy.json` — reference approval policy
- `adapters/demo_mcp_server.py` — local MCP resource/tool server
- `adapters/mock_issue_server.py` — local HTTP server for OpenAPI demos
- `adapters/mock_issue_api.openapi.yaml` — OpenAPI surface for the issue server
- `examples/primer_to_axioms.spell.json` — uses the uploaded primer texts directly
- `examples/primer_via_mcp.spell.json` — reads the primers via MCP, stages output via an MCP tool
- `examples/openapi_ticket_then_fail.spell.json` — creates an issue then intentionally fails to prove rollback
- `artifacts/` — generated outputs, traces, provenance, and SCXML plans

## Quick start

Run the direct-file primer relay:

```bash
cd /mnt/data/axiomurgy
python axiomurgy.py examples/primer_to_axioms.spell.json --approve publish
```

Run the MCP version:

```bash
cd /mnt/data/axiomurgy
python axiomurgy.py examples/primer_via_mcp.spell.json --approve publish
```

Run the OpenAPI rollback demo:

```bash
cd /mnt/data/axiomurgy
python adapters/mock_issue_server.py >/tmp/issue_server.log 2>&1 &
python axiomurgy.py examples/openapi_ticket_then_fail.spell.json --approve create_ticket
```

The last command is expected to **fail on purpose** after the external write.
The runtime should then issue the compensation step and remove the created ticket.

## Approvals

Any step may be approved with:

```bash
python axiomurgy.py <spell.json> --approve step_id
```

You can repeat the flag or use `--approve all`.

## Provenance outputs

Each example writes:

- a PROV-like witness document
- a raw execution trace
- an SCXML representation of the compiled plan

## Current limitations

This is still a reference runtime, not a production orchestration platform.

Notably:

- no real LLM backend is embedded in the runtime
- policy is JSON-based, not a full external policy VM
- OpenAPI support is practical but intentionally narrow
- MCP support is a focused subset suitable for local demos
- execution is ordered and dependency-aware, but not parallelized

## Why this shape

Axiomurgy is designed so that AI systems feel magical in fiction terms but remain inspectable in engineering terms:

- **definitive** because the rules are explicit
- **synergistic** because schema, policy, tools, and provenance interact
- **pluralistic** because several schools of operation coexist
- **meta** because the protocol layer and audience are part of the system

The result is less “wizard with infinite mana” and more “carefully licensed causal graph.”
