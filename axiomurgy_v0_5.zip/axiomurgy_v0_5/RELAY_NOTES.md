# Axiomurgy v0.5 relay notes

What this lap adds:
- spellbook manifests and `spellbook.schema.json`
- runtime support for packaged spellbook entrypoints
- deterministic validator runes
- proof summaries in runtime results and witness files
- a packaged `spellbooks/primer_codex/` example
- expanded tests and smoke coverage for packaged execution

Verified demos in this relay:
- `examples/primer_to_axioms.spell.json`
- `examples/primer_via_mcp.spell.json`
- `examples/openapi_ticket_then_fail.spell.json`
- `spellbooks/primer_codex/`

Why this lap exists:
- direct spell files were useful, but they did not yet provide a clean packaging story
- witness files existed, but there was no compact proof surface for downstream agents or IDEs
- Cursor and other relay agents benefit from packaged entrypoints and deterministic preflight checks

Suggested next relay:
- plan mode for spells and spellbooks
- deterministic linting
- approval manifests
- better preflight summaries for downstream agents and IDEs
